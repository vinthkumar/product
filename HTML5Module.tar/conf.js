exports.config = {
  profile: 'integration',

  baseUrl: 'https://84bc3664trial-workspaces-ws-x5fn5-app1.us10.trial.applicationstudio.cloud.sap/HTML5Module/webapp/index.html',
};